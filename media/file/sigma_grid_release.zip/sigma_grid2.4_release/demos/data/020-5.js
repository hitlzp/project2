{
	
data : [

["008","Crystal",6.84,92,0.38,1,0.4,"Branch","UPS","What?"],
["012","Garnet",25.9,84,0.03,0,0.4,"Deliver Center","UPS","Some notes"],
["006","Citrine",104,72,0.17,0,0.1,"Customer","Other","Deliver to my home"],
["002","Amber",56,3,0.23,1,0.1,"Other","UPS","What?"],
["003","Amethyst",24.8,40,0.33,0,0.2,"Deliver Center","WestUnion","Some notes"],
["017","Pearl",27,54,0.2,0,0.4,"Deliver Center","WestUnion","Some notes"],
["016","Opal",2.3,17,0.18,0,0.3,"Deliver Center","Other","-"],
["011","Enamel",28,62,0.21,0,0.05,"Branch","WestUnion","Deliver to my home"],
["011","Enamel",28,4,0.35,0,0.2,"Branch","UPS","-"],
["013","Glass",45,28,0.14,1,0.05,"Deliver Center","Other","-"],
["001","Abalone",34.5,12,0.33,0,0.3,"Deliver Center","UPS","What?"],
["001","Abalone",34.5,24,0.13,1,0.05,"Deliver Center","Fedex","Some notes"],
["017","Pearl",27,60,0.05,0,0.1,"Deliver Center","UPS","What?"],
["001","Abalone",34.5,66,0.26,1,0.05,"Branch","Other","Deliver to my home"],
["012","Garnet",25.9,63,0.13,0,0.05,"Deliver Center","Other","-"],
["016","Opal",2.3,27,0.01,1,0.05,"Customer","UPS","What?"],
["001","Abalone",34.5,34,0.21,0,0.2,"Branch","UPS","Deliver to my home"],
["009","Cubic Zirconia",24,50,0.22,0,0.1,"Other","Other","Some notes"],
["002","Amber",56,42,0.31,0,0.2,"Branch","Other","What?"]
],
pageInfo : {totalRowNum:19},


exception:''

}