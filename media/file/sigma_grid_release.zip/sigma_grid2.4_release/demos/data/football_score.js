

var __TEST_DATA__=
[
["Brazil","2:3","England"],
["Argentina","4:0","England"],
["France","3:1","England"],
["Argentina","0:1","Brazil"],
["France","2:5","Brazil"],
["France","3:2","Argentina"]

];

