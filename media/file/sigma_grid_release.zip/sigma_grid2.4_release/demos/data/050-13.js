{
	
data : [

["008","Crystal",6.84,92,0.38,1,0.4,"Branch","UPS","What?"],
["012","Garnet",25.9,84,0.03,0,0.4,"Deliver Center","UPS","Some notes"],
["002","Amber",56,42,0.31,0,0.2,"Branch","Other","What?"]
],
pageInfo : {totalRowNum:19},


exception:''

}