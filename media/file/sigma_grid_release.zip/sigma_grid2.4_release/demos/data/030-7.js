{
	
data : [

["002","Amber",56,60,0.18,1,0.4,"Other","WestUnion","Some notes"],
["017","Pearl",27,64,0.33,0,0.05,"Deliver Center","Fedex","What?"],
["016","Opal",2.3,12,0.4,0,0.1,"Deliver Center","WestUnion","-"],
["014","Moissanite",31,45,0.16,0,0.05,"Other","UPS","Some notes"],
["004","Aquamarine",32.4,35,0.17,0,0.3,"Customer","UPS","-"],
["014","Moissanite",31,95,0.1,0,0.1,"Customer","WestUnion","Deliver to my home"],
["017","Pearl",27,91,0.17,1,0.05,"Customer","Fedex","-"],
["011","Enamel",28,4,0.11,1,0.05,"Customer","Fedex","Some notes"],
["014","Moissanite",31,38,0.24,1,0.2,"Deliver Center","WestUnion","-"],
["016","Opal",2.3,38,0.14,0,0.2,"Other","UPS","-"],
["005","Cameos",64.8,17,0.11,1,0.3,"Branch","UPS","-"]
],
pageInfo : {totalRowNum:23},


exception:''

}