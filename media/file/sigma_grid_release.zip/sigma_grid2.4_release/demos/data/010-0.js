{
	
data : [

["007","Coral",12,30,0.33,1,0.1,"Customer","UPS","Some notes"],
["005","Cameos",64.8,77,0.07,1,0.3,"Branch","Fedex","-"],
["004","Aquamarine",32.4,23,0.25,1,0.3,"Deliver Center","UPS","-"],
["013","Glass",45,67,0.16,1,0.05,"Customer","Other","What?"],
["012","Garnet",25.9,84,0.29,0,0.1,"Customer","WestUnion","Deliver to my home"],
["015","Onyx",24.1,56,0.22,1,0.4,"Branch","WestUnion","Deliver to my home"],
["013","Glass",45,53,0.06,0,0.4,"Deliver Center","Fedex","Some notes"],
["005","Cameos",64.8,72,0.3,0,0.3,"Branch","Other","Some notes"],
["007","Coral",12,83,0.39,1,0.4,"Customer","UPS","Deliver to my home"],
["016","Opal",2.3,23,0.13,0,0.05,"Customer","Other","-"],
["014","Moissanite",31,73,0.04,1,0.3,"Branch","WestUnion","What?"],
["012","Garnet",25.9,32,0.32,1,0.05,"Customer","Fedex","What?"],
["002","Amber",56,60,0.18,1,0.4,"Other","WestUnion","Some notes"],
["017","Pearl",27,64,0.33,0,0.05,"Deliver Center","Fedex","What?"],
["016","Opal",2.3,12,0.4,0,0.1,"Deliver Center","WestUnion","-"],
["014","Moissanite",31,45,0.16,0,0.05,"Other","UPS","Some notes"],
["004","Aquamarine",32.4,35,0.17,0,0.3,"Customer","UPS","-"],
["014","Moissanite",31,95,0.1,0,0.1,"Customer","WestUnion","Deliver to my home"],
["017","Pearl",27,91,0.17,1,0.05,"Customer","Fedex","-"],
["011","Enamel",28,4,0.11,1,0.05,"Customer","Fedex","Some notes"],
["014","Moissanite",31,38,0.24,1,0.2,"Deliver Center","WestUnion","-"],
["016","Opal",2.3,38,0.14,0,0.2,"Other","UPS","-"],
["005","Cameos",64.8,17,0.11,1,0.3,"Branch","UPS","-"]
],
pageInfo : {totalRowNum:23},


exception:''

}